import firebase from 'firebase/app';
import "firebase/firestore";
import "firebase/auth";



const firebaseConfig = {
    apiKey: "AIzaSyAquLjMs4nTE8AvNI2RUoZBtPZlnhFOBjc",
    authDomain: "react-apps-de479.firebaseapp.com",
    projectId: "react-apps-de479",
    storageBucket: "react-apps-de479.appspot.com",
    messagingSenderId: "367555790911",
    appId: "1:367555790911:web:564b45844b36bccf48108a"
};

const app = initializeApp(firebaseConfig);

firebase.app;

const db = firebase.firestore();

const googleAuthProvider = new firebase.auth.GoogleAuthProvider();


export{
    db,
    googleAuthProvider,
    firebase
}